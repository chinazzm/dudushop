//index.js

//获取应用实例
var app = getApp()
Page({
  data: {
    orderList: [],
    u_op:"",
  },
  onLoad: function() {
    var that = this;
    /**
     * 订单列表接口
     */
    var dianpu_id = app.globdData.dianpu_id;
    var user_id = wx.getStorageSync('u_id');
    wx.request({
      url: "https://wx.9lele.com/index.php/wx/Index/order_list",
      data: {
        dianpu_id: dianpu_id,
        user_id: user_id
      },
      success: function(res) {
        console.log(res)
        that.setData({
          orderList: res.data.datalist,
        })
      }
    })

    var AppID = 'wxabab7bda8ddc37b3';//动态去微信公众平台查询
    var AppSecret = 'e65cf473731f5a33e89dc995f7ff88f1';//动态去微信公众平台查询
    wx.login({
      success: function (res) {
        wx.request({
          url: 'https://wx.9lele.com/index.php/wx/te/user_login?code=' + res.code + "&dianpu_id=2&AppID=" + AppID + "&AppSecret=" + AppSecret,
          success: function (res) {
            that.setData({
              u_op:res.data.openid
            })
          }
        })
      }
    })



  },
  onUnload: function() {
    wx.reLaunch({
      url: '../my/index'
    })
  },

  lookOrder: function(e) {
    var order_id = e.currentTarget.id;
    var that = this;
    wx.navigateTo({
      url: "../detail/index?id=" + order_id,
    })
  },

  cancelOrder: function(e) {
    var that = this;
    var order_id = e.currentTarget.id;
    wx.request({
      url: "https://wx.9lele.com/index.php/wx/Index/edit_order_status",
      data: {
        order_id: order_id
      },
      success: function(res) {
        wx.showToast({
          title: '取消订单成功!',
          success: res => {
            that.setData({
              orderList: []
            });
            that.onLoad();
          },
          duration: 1000,
        })

      }
    })
  },
  pay: function(res) {
    var by_id = res.currentTarget.id
    var u_op = this.data.u_op
    // console.log(u_op)
    wx.request({
      url: 'https://wx.9lele.com/index.php/wx/index/gotobuy',
      data: {
        by_id: by_id,
        u_op: u_op
      },
      success: function(res) {
        console.log("" + res.data.timeStamp + "")
        wx.requestPayment({
          timeStamp: "" + res.data.timeStamp + "",
          nonceStr: res.data.nonce_str,
          package: res.data.prepay_id,
          signType: 'MD5',
          paySign: res.data.paySign,
          success: function(e) {
            console.log(e)
          },
          fail: function(e) {
            console.log(e)
          },
          complete:function(e){
            console.log(e)
          }
        })
      }
    })
  }

})