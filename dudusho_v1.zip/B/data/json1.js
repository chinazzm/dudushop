var json = {
  "0":{
    "id":1,
    "goods_name": "洁面皂",
    "goods_img": "http://mz.djmall.xmisp.cn/files/logo/20161208/148117972563.jpg",
    "goods_price": 1000 ,
    "create_time":"2018-10-8",
    "select": "circle",
    "num":"1",
  }, 
  "1": {
    "id": 2,
    "goods_name": "卸妆水",
    "goods_img": "http://mz.djmall.xmisp.cn/files/logo/20161207/148110444480.jpg",
    "goods_price": 350,
    "create_time": "2018-10-8",
    "select": "circle",
    "num": "1",
  }, 
  "2": {
    "id": 3,
    "goods_name": "洁面乳",
    "goods_img": "http://mz.djmall.xmisp.cn/files/logo/20161208/148117973270.jpg",
    "goods_price": 85,
    "create_time": "2018-10-8",
    "select": "circle",
    "num": "2",
  }, 
  "3": {
    "id": 4,
    "goods_name": "粉饼",
    "goods_img": "http://mz.djmall.xmisp.cn/files/logo/20161212/148153816983.jpg",
    "goods_price": 2100,
    "create_time": "2018-10-8",
    "select": "circle",
    "num": "3",
  }, 
   
}

module.exports = {
  dataList: json
}